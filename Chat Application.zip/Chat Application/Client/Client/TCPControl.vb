﻿Imports System.Net
Imports System.Net.Sockets
Imports System.IO

Public Class TCPControl
    Public ClientProperty As TcpClient
    Public DataStream As StreamWriter

    Public Sub New(Host As String, Port As Integer)
        'CLIENT
        ClientProperty = New TcpClient(Host, Port)
        DataStream = New StreamWriter(ClientProperty.GetStream)
    End Sub

    Public Sub Send(Data As String)
        DataStream.Write(Data & vbCrLf)
        DataStream.Flush()

    End Sub
End Class
