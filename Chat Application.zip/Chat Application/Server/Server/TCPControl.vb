﻿Imports System.IO
Imports System.Net
Imports System.Net.Sockets
Imports System.Threading

Public Class TCPControl

    Public Event messageReceived(Sender As TCPControl, Data As String)

    'SERVER CONFIG
    Public ServerIP As IPAddress = IPAddress.Parse("192.168.1.153") 'MY IPADDRESS
    Public ServerPort As Integer = 64555 'CAN NOT TWO APPS LISTENING AT THE SAME PORT
    Public Server As TcpListener

    Private CommThread As Thread
    Public IsListening As Boolean = True

    'CLIENTS CONFIG
    Private Client As TcpClient
    Private ClientData As StreamReader 'READING FROM NETWORK STREAM

    Public Sub New()
        Server = New TcpListener(ServerIP, ServerPort)
        Server.Start()
        CommThread = New Thread(New ThreadStart(AddressOf Listening)) ' Keep eye on the server

        CommThread.Start()
    End Sub

    Private Sub Listening()
        'LISTENER LOOP KEEPING AN EYE TO THE SERVER 
        'AS WELL AS READING DATA 
        Do Until IsListening = False
            'ACCEPT INCOMING CONN
            If Server.Pending = True Then
                Client = Server.AcceptTcpClient
                ClientData = New StreamReader(Client.GetStream)  'GRAP DATASTREAM FOR THAT CLIENT
            End If

            'RAISE THE EVENT EVERYTIME FOR INCOMING MESSAGES
            Try
                RaiseEvent messageReceived(Me, ClientData.ReadLine)

            Catch ex As Exception

            End Try

            'REDUCE CPU USAGE
            Thread.Sleep(100) 'MS >> FOR MISSCONNECTIONS
        Loop

    End Sub
End Class


' 192.168.1.153

