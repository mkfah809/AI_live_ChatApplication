﻿Public Class frmServer

    Private Server As TCPControl

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Server.IsListening = False 'WILL BREAK THE LOOP
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Server = New TCPControl 'FIRE A NEW SUB 
        txtChat.Text = ":: SERVER STARTED ::" & vbCrLf

        AddHandler Server.messageReceived, AddressOf OnLineReceived
    End Sub

    Private Delegate Sub UpdateTextDelegate(TB As TextBox, txt As String)
    ' NO END SUB >>

    'UPDATE TEXTBOX
    Private Sub UpdateText(TB As TextBox, txt As String)
        If TB.InvokeRequired Then
            TB.Invoke(New UpdateTextDelegate(AddressOf UpdateText), New Object() {TB, txt})
        Else
            If txt IsNot Nothing Then
                TB.AppendText(txt & vbCrLf)
            End If
        End If
    End Sub

    Private Sub OnLineReceived(Sender As TCPControl, Data As String)
        'TEXT UPDATE
        UpdateText(txtChat, Data)

    End Sub


End Class
