﻿Public Class Form1
    Private Client As TCPControl

    Private Sub btnConnect_Click(sender As Object, e As EventArgs) Handles btnConnect.Click
        Try
            Client = New TCPControl("192.168.1.153", 64555)
            If Client.Client.Connected Then
                btnConnect.Text = "Connected"

            End If
        Catch ex As System.Net.Sockets.SocketException
            MessageBox.Show("An error has occured" & Environment.NewLine & "Please switch on your server")

        Catch ex As System.NullReferenceException
            MessageBox.Show("An error has occured" & Environment.NewLine & "Please try again")

        End Try
    End Sub

    Private Sub btnSend_Click(sender As Object, e As EventArgs) Handles btnSend.Click
        SendMessage()
        txtMessage.Clear()
        txtMessage.Focus()
    End Sub

    Private Sub SendMessage()
        Try
            If Client.Client.Connected = True Then
                Client.Send("Tester2:: " & txtMessage.Text)
            End If
        Catch ex As System.NullReferenceException
            MessageBox.Show("An error has occured" & Environment.NewLine & "You can not send an empty message")
        End Try
    End Sub

    Private Sub Form1_FormClosing(sender As Object, e As FormClosingEventArgs) Handles Me.FormClosing
        Try
            If Client.Client.Connected = True Then
                Client.DataStream.Close()
                Client.Client.Close()
            End If
        Catch ex As System.NullReferenceException
            If MsgBox("Are you sure?", MsgBoxStyle.OkOnly) = MsgBoxResult.Ok Then


        End If
        End Try
    End Sub

    Private Sub txtMessage_KeyDown(sender As Object, e As KeyEventArgs) Handles txtMessage.KeyDown
        If e.KeyCode = Keys.Enter Then
            SendMessage()
            txtMessage.Clear()
        End If
    End Sub
End Class
