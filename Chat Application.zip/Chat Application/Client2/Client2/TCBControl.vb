﻿Imports System.Net
Imports System.Net.Sockets
Imports System.IO

Public Class TCPControl
    Public Client As TcpClient
    Public DataStream As StreamWriter

    Public Sub New(Host As String, Port As Integer)
        'CLIENT
        Try
            Client = New TcpClient(Host, Port)
            DataStream = New StreamWriter(Client.GetStream)

        Catch
            MessageBox.Show("Please Turn on your Server")
        End Try
    End Sub

    Public Sub Send(Data As String)
        DataStream.Write(Data & vbCrLf)
        DataStream.Flush()

    End Sub
End Class

Public Class TCBControl

End Class
